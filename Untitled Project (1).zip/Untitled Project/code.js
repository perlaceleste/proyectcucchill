var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["34e8ff88-8f28-40f0-8def-fdce1f8f1719","44d7c015-2c47-4658-b42c-38b55970b707","ef65ed0e-96a6-4665-aaa3-7a482cb2c192","de3d8ef9-5755-4421-b3e4-39f3ff9c487e"],"propsByKey":{"34e8ff88-8f28-40f0-8def-fdce1f8f1719":{"name":"cuchillo","categories":["tools"],"frameCount":1,"frameSize":{"x":128,"y":128},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-05 19:43:51 UTC","pngLastModified":"2021-01-05 19:44:24 UTC","version":"G0.c2WGl4_7kHUquBeS3q.OHykWk4QqR","sourceUrl":"assets/api/v1/animation-library/gamelab/G0.c2WGl4_7kHUquBeS3q.OHykWk4QqR/category_tools/knife_blue.png","sourceSize":{"x":128,"y":128},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/G0.c2WGl4_7kHUquBeS3q.OHykWk4QqR/category_tools/knife_blue.png"},"44d7c015-2c47-4658-b42c-38b55970b707":{"name":"manzana","categories":["food"],"frameCount":1,"frameSize":{"x":333,"y":399},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-12 02:00:59 UTC","pngLastModified":"2021-01-12 02:01:00 UTC","version":"R5HU7H.MzPJgfu.WtncglTeef4BzKuzc","sourceUrl":"assets/api/v1/animation-library/gamelab/R5HU7H.MzPJgfu.WtncglTeef4BzKuzc/category_food/apple_1.png","sourceSize":{"x":333,"y":399},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/R5HU7H.MzPJgfu.WtncglTeef4BzKuzc/category_food/apple_1.png"},"ef65ed0e-96a6-4665-aaa3-7a482cb2c192":{"name":"zanahoria","categories":["food"],"frameCount":1,"frameSize":{"x":389,"y":383},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-12 02:09:48 UTC","pngLastModified":"2021-01-12 02:09:48 UTC","version":"BJiujt1JCKr8EcsbZ.IDJM.CxfYn9HOJ","sourceUrl":"assets/api/v1/animation-library/gamelab/BJiujt1JCKr8EcsbZ.IDJM.CxfYn9HOJ/category_food/carrot_1.png","sourceSize":{"x":389,"y":383},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/BJiujt1JCKr8EcsbZ.IDJM.CxfYn9HOJ/category_food/carrot_1.png"},"de3d8ef9-5755-4421-b3e4-39f3ff9c487e":{"name":"jitomate","categories":["food"],"frameCount":1,"frameSize":{"x":396,"y":382},"looping":true,"frameDelay":2,"jsonLastModified":"2021-01-05 17:42:40 UTC","pngLastModified":"2021-01-05 17:38:37 UTC","version":"f7D9PY.90gXQmTls.lrGEI7iwAyCpay5","sourceUrl":"assets/api/v1/animation-library/gamelab/f7D9PY.90gXQmTls.lrGEI7iwAyCpay5/category_food/gamefood07.png","sourceSize":{"x":396,"y":382},"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/api/v1/animation-library/gamelab/f7D9PY.90gXQmTls.lrGEI7iwAyCpay5/category_food/gamefood07.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var cuchillo = createSprite(200, 200, 50, 15);
   cuchillo.setAnimation("cuchillo");
   cuchillo.scale=0.6;
   


var manzana= createSprite(350,200,10,100);
  manzana.setAnimation("manzana");
  manzana.scale=0.2;


function draw(){
  background("blue");
  

  
  
   var zanahoria = createSprite(250, 90);
       zanahoria.setAnimation("zanahoria");
      zanahoria.scale=0.2;

 var jitomate = createSprite(100, 300);
     jitomate.setAnimation("jitomate");
     jitomate.scale=0.2;
   
  cuchillo.x=World.mouseX;
  
 
 

  
  drawSprites();

}

  


  



// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
